This folder contains useful info for plugin developers.

If you just use `markdown-it` in your app, see
[README](https://github.com/markdown-it/markdown-it#markdown-it) and
[API docs](https://markdown-it.github.io/markdown-it/).

__Content__:

- [Parser architecture & design principles](architecture.md)
- [Some guidelines for plugin developers](development.md)
