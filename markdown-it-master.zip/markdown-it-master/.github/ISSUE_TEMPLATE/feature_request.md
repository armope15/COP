---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

<!--

Please note, this package is highly extendable. Prior to request new feature, make sure it can not be implemented via plugins.

You may also find useful this links:

- https://github.com/markdown-it - list of "officially" provided plugins.
- https://www.npmjs.com/search?q=keywords:markdown-it-plugin - community-written plugins.
- https://github.com/markdown-it/markdown-it/tree/master/docs - docs for plugin developers.

-->
