---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

<!--

Please note, this package is about IMPLEMENTATION of CommonMark https://commonmark.org/, not about markdown itself. We stay aside of markup discussions. Prior to report a bug, make sure it's about this package, not generic thing.

**Before you post**

1. https://spec.commonmark.org/ - make sure you've read CommonMark spec.
2. https://spec.commonmark.org/dingus/ - if you think you found parse error, check it in reference implementation first.

**In your report** 

It will be very helpful, if you can provide permalinks with online samples and explain the difference:

- https://markdown-it.github.io/ - online demo of `markdown-it`.
- https://spec.commonmark.org/dingus/ - online demo of reference CommonMark's implementation.

If you wish to provide code sample - make sure it is as small as possible and can be executed.

-->
