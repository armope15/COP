
``````````text
an
example
```
of


a fenced
```
code
block
``````````

